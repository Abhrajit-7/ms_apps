package com.customers.customers.controller;

import com.customers.customers.dto.Reservation;
import com.customers.customers.entity.Customer;
import com.customers.customers.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public ResponseEntity<Object> createCustomer(@RequestBody Customer customer) throws Exception{
        return ResponseEntity.ok(customerService.createCustomer(customer));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> fetchCustomerById(@PathVariable(value = "id") Long customerId) throws Exception{
        return ResponseEntity.ok(customerService.fetchCustomerById(customerId));
    }

    @GetMapping("/")
    public ResponseEntity<Object> fetchAllCustomers() throws Exception{
        return ResponseEntity.ok(customerService.fetchAllCustomers());
    }

    @PutMapping("/")
    public ResponseEntity<Object> updateCustomer(@RequestBody Customer customer) throws Exception{
        return ResponseEntity.ok(customerService.updateCustomer(customer));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteCustomerById(@PathVariable(value = "id") Long customerId) throws Exception{
        return ResponseEntity.ok(customerService.deleteCustomerById(customerId));
    }

    @PostMapping("/makereservation")
    public ResponseEntity<Object> makeReservasion(@RequestBody Reservation reservation) throws Exception{
        return ResponseEntity.ok(customerService.makeReservation(reservation));
    }

    @GetMapping("/cancelreservation/{id}")
    public ResponseEntity<Object> cancelReservation(@PathVariable(value = "id") Long reservationId) throws Exception{
        return ResponseEntity.ok(customerService.cancelReservation(reservationId));
    }
}
