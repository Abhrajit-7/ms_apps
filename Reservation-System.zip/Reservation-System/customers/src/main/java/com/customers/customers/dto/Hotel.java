package com.customers.customers.dto;

import lombok.Data;

@Data
public class Hotel {
    private Long id;

    private String name;

    private String description;

    private String status;
}
