package com.customers.customers.dto;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class Reservation {
    private Long customerId;

    private Long hotelId;

    private BigDecimal bookingAmount;

    private String startDate;

    private String endDate;

    private Long paymentID;
}
