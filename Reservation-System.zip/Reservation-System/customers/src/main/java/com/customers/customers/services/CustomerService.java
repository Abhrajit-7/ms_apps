package com.customers.customers.services;

import com.customers.customers.dto.Hotel;
import com.customers.customers.dto.Notification;
import com.customers.customers.dto.Reservation;
import com.customers.customers.entity.Customer;
import com.customers.customers.entity.ReservationEntity;
import com.customers.customers.repository.CustomerRepository;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class CustomerService {

    @Autowired
    private CustomerRepository customersRepository;

    @Autowired
    private KafkaService kafkaService;

    @Autowired
    private Gateway gateway;

    public Customer createCustomer(Customer customer) throws Exception {
        Optional<Customer> existCustomer = customersRepository.findByEmail(customer.getEmail());
        if (!existCustomer.isPresent()) {
            Customer createdCustomer = customersRepository.save(customer);
            if (Objects.nonNull(createdCustomer)) {
                kafkaService.sendNotification(Notification.builder()
                        .customerId(createdCustomer.getId())
                        .eventType("customer registered")
                        .message("Welcome To Hotel Reservation")
                        .build());
            }

            return createdCustomer;
        } else {
            throw new Exception("Customer with email " + customer.getEmail() + " is Already Exists.");
        }
    }


    public Customer fetchCustomerById(Long customerId) throws Exception {
        Optional<Customer> customerOptional = customersRepository.findById(customerId);
        if (customerOptional.isPresent()) {
            return customerOptional.get();
        } else {
            throw new ResourceNotFoundException("No customer");
        }
    }

    public List<Customer> fetchAllCustomers() {
        return customersRepository.findAll();
    }

    public Customer updateCustomer(Customer customers) throws Exception {
        Optional<Customer> customersOptional = customersRepository.findById(customers.getId());
        if (customersOptional.isPresent()) {
            return customersRepository.save(customers);
        } else {
            throw new ResourceNotFoundException("Customer is not Exists.");
        }
    }


    public String deleteCustomerById(Long customerId) {
        Optional<Customer> customersOptional = customersRepository.findById(customerId);
        if (customersOptional.isPresent()) {
            customersRepository.deleteById(customerId);
            return "Success";
        } else {
            throw new ResourceNotFoundException("Customer Not Found");
        }
    }

    // Customer Initiate For Booking Hotel
    public String makeReservation(Reservation reservation) throws Exception {
        Optional<Customer> customerOp = customersRepository.findById(reservation.getCustomerId());
        if (customerOp.isPresent()) {
            Customer customer = customerOp.get();
            Hotel hotel = gateway.getHotel(reservation.getHotelId());
            if (hotel != null && "AVAILABLE".equalsIgnoreCase(hotel.getStatus())) {
                // Send Message to Reservation-Service
                kafkaService.sendBookingNotification(Reservation.builder()
                        .customerId(customer.getId())
                        .bookingAmount(reservation.getBookingAmount())
                        .startDate(reservation.getStartDate())
                        .endDate(reservation.getEndDate())
                        .build());
                return "Your Hotel Booking is in progress";
            } else {
                // Send Notification as Booking Not Available
                kafkaService.sendNotification(Notification.builder()
                        .customerId(customer.getId())
                        .eventType("Hotel")
                        .message("Not available")
                        .build());
                return "Not available";
            }
        } else {
            throw new ResourceNotFoundException("Customer doesn't exist");
        }
    }

    // Customer Cancel Hotel Booking
    // Updating Hotel Status to AVAILABLE
    // Reservation Status to CANCELLED
    // Payment Status to REFUND
    // Send Notification to Customer for Cancelled Reservation
    public String cancelReservation(Long reservationId) throws Exception {

        ReservationEntity reservationEntity = gateway.getReservationById(reservationId);
        gateway.updateHotelBookingStatus(reservationEntity.getHotelId(), "AVAILABLE");
        gateway.updatePaymentStatus(reservationEntity.getPaymentId(), "REFUND");
        gateway.updateReservationStatus(reservationId, "CANCELLED");

        // Send Notification as Reservation is Cancelled
        kafkaService.sendNotification(Notification.builder()
                .customerId(reservationEntity.getCustomerId())
                .eventType("reservation")
                .message("Customer Reservation for Hotel is Cancelled, Reservation ID :: " + reservationId)
                .build());
        return "Customer Reservation for Hotel is Cancelled";

    }
}
