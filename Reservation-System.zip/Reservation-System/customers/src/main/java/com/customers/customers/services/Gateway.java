package com.customers.customers.services;

import com.customers.customers.dto.Hotel;
import com.customers.customers.entity.Payment;
import com.customers.customers.dto.Reservation;
import com.customers.customers.entity.ReservationEntity;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "apigateway-service", url = "http://localhost:8000", path = "/")
public class Gateway {
    @GetMapping("/hotel/{hotelId}")
    public Hotel getHotel(@PathVariable Long hotelId) {
        return null;
    }


    @GetMapping("/reservations/{id}")
    public ReservationEntity getReservationById(@PathVariable Long id) {
        return null;
    }

    @GetMapping("/payments/{id}/paymentstatus/{status}")
    public Payment updatePaymentStatus(@PathVariable Long id, @PathVariable String status) {
        return null;
    }

    @GetMapping("/reservations/{id}/reservationstatus/{status}")
    public Reservation updateReservationStatus(@PathVariable Long id, @PathVariable String status) {
        return null;
    }

    @GetMapping("/hotels/{hotelId}/bookingstatus/{status}")
    public Hotel updateHotelBookingStatus(Long hotelId, String available) {
        return null;
        
    }
}
