package com.customers.customers.services;

import com.customers.customers.dto.Notification;
import com.customers.customers.dto.Reservation;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

public class KafkaService {
    @Autowired
    private NewTopic topic;

    @Autowired
    private NewTopic topicBooking;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendBookingNotification(Reservation.ReservationBuilder reservation) throws Exception{

        ObjectMapper mapper = new ObjectMapper();
        String messageWrite = mapper.writeValueAsString(reservation);
        Message<String> message = MessageBuilder
                .withPayload(messageWrite)
                .setHeader(KafkaHeaders.TOPIC, topic.name())
                .build();
        kafkaTemplate.send(message);
    }

    public void sendNotification(Notification reservation) throws Exception{

        ObjectMapper mapper = new ObjectMapper();
        String messageWrite = mapper.writeValueAsString(reservation);
        Message<String> message = MessageBuilder
                .withPayload(messageWrite)
                .setHeader(KafkaHeaders.TOPIC, topicBooking.name())
                .build();
        kafkaTemplate.send(message);
    }

    public void sendBookingNotification(Reservation build) {
    }
}
