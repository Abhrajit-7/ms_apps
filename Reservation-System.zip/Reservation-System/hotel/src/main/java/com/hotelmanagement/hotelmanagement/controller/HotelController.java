package com.hotelmanagement.hotelmanagement.controller;

import com.hotelmanagement.hotelmanagement.entity.Hotel;
import com.hotelmanagement.hotelmanagement.services.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotel")
public class HotelController {
    @Autowired
    HotelService hotelService;


    @GetMapping("/")
    public List<Hotel> getAllHotel(){
        return hotelService.getAllHotel();
    }

    @PostMapping("/addHotel")
    public Hotel addHotel(@RequestBody Hotel hotel) {
        return hotelService.addHotel(hotel);

    }
    @GetMapping("/{hotelId}")
    public Hotel getHotel(@PathVariable Long hotelId){
        return hotelService.getHotel(hotelId);

    }

    @GetMapping("/{hotelId}/bookingstatus/{status}")
    public Hotel updateHotelBookingStatus(@PathVariable Long hotelId,@PathVariable String status){
        return hotelService.updateHotelBookingStatus(hotelId,status);
    }
}
