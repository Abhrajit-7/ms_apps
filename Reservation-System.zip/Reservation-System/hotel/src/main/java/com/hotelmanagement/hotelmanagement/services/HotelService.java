package com.hotelmanagement.hotelmanagement.services;

import com.hotelmanagement.hotelmanagement.entity.Hotel;
import com.hotelmanagement.hotelmanagement.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class HotelService {
    @Autowired
    HotelRepository hotelRepository;

    public List<Hotel> getAllHotel(){
        return hotelRepository.findAll();
    }

    public Hotel addHotel(Hotel hotel) {
        hotel.setStatus("AVAILABLE");
        return hotelRepository.save(hotel);
    }

    public Hotel getHotel(Long hotelId) {
        return hotelRepository.findById(hotelId).orElse(null);
    }

    public Hotel updateHotelBookingStatus(Long hotelId, String status) {
        Hotel hotel =  getHotel(hotelId);
        if(hotel!=null) {
            hotel.setStatus(status);
            return hotelRepository.save(hotel);
        } else {
            return hotel;
        }
    }
}
