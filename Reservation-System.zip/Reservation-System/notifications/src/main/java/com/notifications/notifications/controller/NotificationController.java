package com.notifications.notifications.controller;

import com.notifications.notifications.entity.Notification;
import com.notifications.notifications.services.NotificationServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notification_panel")
public class NotificationController {
    @Autowired
    NotificationServices notificationServices;

    @PostMapping("/send")
    public String sendNotification() {
        return null;
    }

    @GetMapping("/customer/{customerId}")
    public List<Notification> getNotificationBycautomerId(@PathVariable Long customerId) {
        return notificationServices.getAllNotifications(customerId);
    }
}
