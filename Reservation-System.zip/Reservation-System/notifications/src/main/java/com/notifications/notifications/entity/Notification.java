package com.notifications.notifications.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.data.annotation.Id;

@Entity
@Data
@Table(name = "notifs")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "message")
    private String message;

    @Column(name = "created_on")
    private String createdOn;
}
