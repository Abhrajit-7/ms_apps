package com.notifications.notifications.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.notifications.notifications.entity.Notification;
import com.notifications.notifications.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

import static org.hibernate.query.sqm.tree.SqmNode.log;

@Service
public class NotificationServices {
    @Autowired
    NotificationRepository notificationRepository;

    // Receiving Message from customer and reservation services
    @KafkaListener(topics = "${spring.kafka.topic.name}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void customerNotify(String notificationPayload) {
        log.info("message {}");

        ObjectMapper mapper = new ObjectMapper();
        Notification notificationEvent = null;
        try {
            notificationEvent = mapper.readValue(notificationPayload, Notification.class);
        } catch (JsonMappingException e) {

            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (notificationEvent != null) {
            notificationEvent.setCreatedOn(new Date().toString());
            notificationRepository.save(notificationEvent);
        } else {
            log.info("no message present");
        }

    }

    public List<Notification> getAllNotifications(Long customerId) {
        return notificationRepository.findByCustomerId(customerId);
    }
}
