package com.payment.payment.controller;

import com.payment.payment.entity.Payment;
import com.payment.payment.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    PaymentRepository paymentRepository;

    @PostMapping
    public Payment makePayment(@RequestBody Payment payment) {
        return paymentRepository.save(payment);
    }

    @GetMapping("/{id}")
    public List<Payment> getPaymentById(@PathVariable Long id) {
        return paymentRepository.findByCustomerId(id);
    }

    @GetMapping("/{id}/paymentstatus/{status}")
    public Payment updatePaymentStatus(@PathVariable Long id,@PathVariable String status){
        Payment payment =  paymentRepository.findById(id).orElse(null);
        if(Objects.nonNull(payment)) {
            payment.setStatus(status);
            return paymentRepository.save(payment);
        } else {
            return payment;
        }
    }
}
