package com.reservation.reservation.controller;

import com.reservation.reservation.entity.Reserve;
import com.reservation.reservation.repository.ReserveRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/reservation")
public class ReserveContoller {
    @Autowired
    private ReserveRepo reserveRepo;

    @GetMapping("/")
    public List<Reserve> getReservations() {
        return reserveRepo.findAll();
    }

    @GetMapping("/{id}")
    public Reserve getReservationById(@PathVariable Long id) {
        return reserveRepo.findById(id).get();
    }

    @GetMapping("/{id}/reservationstatus/{status}")
    public Reserve updateReservationStatus(@PathVariable Long id,@PathVariable String status){
        Reserve reserve =  reserveRepo.findById(id).orElse(null);
        if(Objects.nonNull(reserve)) {
            reserve.setStatus(status);
            return reserveRepo.save(reserve);
        } else {
            return reserve;
        }
    }
}
