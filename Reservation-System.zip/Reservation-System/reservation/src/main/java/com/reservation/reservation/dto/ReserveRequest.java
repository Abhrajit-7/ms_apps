package com.reservation.reservation.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data

public class ReserveRequest {

    private Long customerId;

    private Long hotelId;

    private BigDecimal bookingAmount;

    private String startDate;

    private String endDate;
}
