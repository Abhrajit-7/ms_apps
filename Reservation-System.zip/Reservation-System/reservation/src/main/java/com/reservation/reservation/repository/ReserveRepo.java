package com.reservation.reservation.repository;

import com.reservation.reservation.entity.Reserve;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReserveRepo extends JpaRepository<Reserve, Long> {
}
