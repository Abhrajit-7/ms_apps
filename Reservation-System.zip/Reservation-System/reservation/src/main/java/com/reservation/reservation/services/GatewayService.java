package com.reservation.reservation.services;

import com.reservation.reservation.dto.Hotel;
import com.reservation.reservation.dto.Payment;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "apigateway-service", url = "http://localhost:8888", path = "/")
public class GatewayService {
    @GetMapping("/hotels/{hotelId}/bookingstatus/{status}")
    public Hotel updateHotelBookingStatus(@PathVariable Long hotelId, @PathVariable String status) {
        return null;
    }

    @GetMapping("/hotels/{hotelId}")
    public Hotel getHotel(@PathVariable Long hotelId) {
        return null;
    }

    @PostMapping("/payments")
    public Payment makePayment(@RequestBody Payment payment) {
        return null;
    }
}
