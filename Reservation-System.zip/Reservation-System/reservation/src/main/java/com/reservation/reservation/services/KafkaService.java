package com.reservation.reservation.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.reservation.reservation.dto.Notification;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

public class KafkaService {
    @Autowired
    private NewTopic topic;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendNotification(Notification notification) throws Exception{

        ObjectMapper mapper = new ObjectMapper();
        String messageWrite = mapper.writeValueAsString(notification);
        Message<String> message = MessageBuilder
                .withPayload(messageWrite)
                .setHeader(KafkaHeaders.TOPIC, topic.name())
                .build();
        kafkaTemplate.send(message);
    }
}
