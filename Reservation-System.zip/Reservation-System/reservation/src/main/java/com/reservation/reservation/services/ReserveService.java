package com.reservation.reservation.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.reservation.reservation.dto.Hotel;
import com.reservation.reservation.dto.Notification;
import com.reservation.reservation.dto.Payment;
import com.reservation.reservation.dto.ReserveRequest;
import com.reservation.reservation.entity.Reserve;
import com.reservation.reservation.repository.ReserveRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

import static org.hibernate.query.sqm.tree.SqmNode.log;

public class ReserveService {
    @Autowired
    ReserveRepo reservationRepository;

    @Autowired
    GatewayService gatewayService;

    @Autowired
    private KafkaService kafkaService;

    // Receiving Message from Customer Service Where Make Reservation Initiated
    @KafkaListener(topics = "${spring.kafka.topic.booking}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void reservationProcess(String reservationPayload) throws Exception {
        log.info("message {}");

        ObjectMapper mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        ReserveRequest reserveRequest = null;
        try {
            reserveRequest = mapper.readValue(reservationPayload, ReserveRequest.class);
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        if (reserveRequest != null) {
            Hotel hotel = gatewayService.getHotel(reserveRequest.getHotelId());
            if (hotel != null && "AVAILABLE".equalsIgnoreCase(hotel.getStatus())) {
                Reserve reserve = reservationRepository.save(Reserve.builder()
                        .hotelId(reserveRequest.getHotelId())
                        .customerId(reserveRequest.getCustomerId())
                        .bookingAmount(reserveRequest.getBookingAmount())
                        .startDate(reserveRequest.getStartDate())
                        .endDate(reserveRequest.getEndDate())
                        .status("Transit")
                        .build());


                try {
                    Payment payment = new Payment();
                    payment.setCustomerId(reserveRequest.getCustomerId());
                    payment.setAmount(reserveRequest.getBookingAmount());
                    payment.setStatus("PAID");
                    Payment paid = gatewayService.makePayment(payment);
                    reserve.setPaymentId(paid.getId());
                } catch (Exception ex){
                    ex.printStackTrace();

                    reserve.setStatus("FAILED");
                    reservationRepository.save(reserve);
                    kafkaService.sendNotification(Notification.builder()
                            .customerId(reserveRequest.getCustomerId())
                            .eventType("Payment Failed")
                            .message("Your Room is not booked for Hotel " + hotel.getName()
                                    + " For Date : " + reserveRequest.getStartDate().toString()
                                    + " To Date : " + reserveRequest.getEndDate().toString()
                                    + " \n Reason : Payment Failed")
                            .build());
                    throw new Exception("Payment Failed :: " + ex.getMessage());
                }
                gatewayService.updateHotelBookingStatus(hotel.getId(), "BOOKED");

                kafkaService.sendNotification(Notification.builder()
                        .customerId(reserveRequest.getCustomerId())
                        .eventType("Booking confirmed")
                        .message("Your Room is Booked in Hotel " + hotel.getName()
                                + " For Date : " + reserveRequest.getStartDate().toString()
                                + " To Date : " + reserveRequest.getEndDate().toString())
                        .build());
                reserve.setStatus("Completed");
                reservationRepository.save(reserve);
            } else {
                kafkaService.sendNotification(Notification.builder()
                        .customerId(reserveRequest.getCustomerId())
                        .eventType("Booking not confirmed")
                        .message("Your Room is not available for Hotel " + hotel.getName()
                                + " For Date : " + reserveRequest.getStartDate().toString()
                                + " To Date : " + reserveRequest.getEndDate().toString())
                        .build());
            }
        } else {
            log.info("NULL");
        }
    }
}
